 &clmexp
 site           = 'global.10deg'
 flai           = ''
 fgrid          = '/home/jidy/CoLM_csm/data/global.10deg.grid.pft'
 fmet           = '/home/jidy/swgfs/Princeton_30MIN_10x10'
 fout           = '/home/jidy/swgfs/colm_esm/global'
 fconst         = '/home/jidy/CoLM_csm/data/global.10deg.const.pft'
 frestart       = '/home/jidy/swgfs/colm_esm/global-restart-1990-12-31-22'
 lugrid         = 100
 lulai          = 110
 lumet          = 140
 luhistory      = 150
 lurestart      = 160
 luconst        = 160
 lon_points     = 36
 lat_points     = 18
 numcolumn      = 383
 numpatch       = 3567
 dtime          = 1800.00000000000     
 mstep          = 9120000
 /
